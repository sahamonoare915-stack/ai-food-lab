# AI × Food Lab

实验室网站的 GitHub Pages 发布版本，包含中英文介绍、研究项目、近期代表性论文、成果配图、导师介绍和实验空间。

## 发布

`docs/` 已包含编译后的完整静态网站，无需在 GitHub 上安装依赖或配置服务器。

1. 将本仓库上传至 GitHub 的公开仓库。
2. 在仓库 **Settings → Pages → Build and deployment → Source** 中选择 **GitHub Actions**。
3. 在 **Actions → Publish lab website → Run workflow** 启动发布；以后向 main 推送更新会自动发布。
4. 最终公开网址以 **Settings → Pages** 页面显示的地址为准。

也可以把 Source 设为 **Deploy from a branch**，选择 **main /docs**。请只选一种发布方式。

## 本地修改

需要 Node.js 22.13 或更新版本及 pnpm。

```sh
pnpm install --frozen-lockfile
pnpm dev
pnpm check
pnpm build
```

修改内容后运行 `pnpm build`，把源码和更新后的 `docs/` 一并提交。
图片和 PDF 使用相对路径，支持 `https://用户名.github.io/仓库名/`、用户主页和自定义域名。

## 内容与来源

- `app/page.tsx`：主页与实验室介绍
- `app/poster-projects.tsx`：四个研究项目
- `app/publications.json`：17 篇论文及中文译名、亮点、图片信息
- `app/publication-gallery.tsx`：论文与两篇作者文稿展示
- `public/images/`：网站图片
- `public/papers/`：已用于公开网站的论文 PDF
- `content-sources.md`、`publication-image-sources.json`：内容与配图来源

本仓库只包含网站所需内容。原始 PPT、完整 Word 文稿、本地账号信息和原托管平台配置均未包含。
论文图片和其他第三方素材的权利归原作者或出版方所有；公开仓库不改变这些素材的原有授权。
