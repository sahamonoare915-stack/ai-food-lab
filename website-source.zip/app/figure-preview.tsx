'use client';

import { Expand, ArrowUpRight } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

export type FigureCrop = { x: number; y: number; width: number; height: number; sourceWidth: number; sourceHeight: number };
type Props = { src: string; title: string; caption: string; sourceHref?: string; sourceLabel?: string; crop?: FigureCrop; className?: string; en?: boolean };

function FigureImage({ src, title, crop }: Pick<Props, 'src' | 'title' | 'crop'>) {
  if (crop) return <div className="figure-crop" style={{ aspectRatio: `${crop.width}/${crop.height}` }}><img src={src} alt={title} loading="lazy" width={crop.sourceWidth} height={crop.sourceHeight} style={{ width: `${crop.sourceWidth / crop.width * 100}%`, left: `${-crop.x / crop.width * 100}%`, top: `${-crop.y / crop.height * 100}%` }}/></div>;
  return <img src={src} alt={title} loading="lazy" className="figure-image"/>;
}

export function FigurePreview({ src, title, caption, sourceHref, sourceLabel, crop, className = '', en = false }: Props) {
  return <Dialog><DialogTrigger className={`figure-trigger ${className}`} style={crop ? {maxWidth: Math.min(355, crop.width / crop.height * 196)} : undefined} aria-label={`${en ? 'Enlarge figure: ' : '放大查看：'}${title}`}><FigureImage src={src} title={title} crop={crop}/><span className="figure-expand"><Expand size={15}/><span>{en ? 'View figure' : '查看大图'}</span></span></DialogTrigger><DialogContent className="figure-modal sm:max-w-5xl"><DialogTitle>{title}</DialogTitle><DialogDescription>{caption}</DialogDescription><div className="figure-modal-image"><FigureImage src={src} title={title} crop={crop}/></div>{sourceHref && <a className="text-link figure-source" href={sourceHref} target="_blank" rel="noopener noreferrer">{sourceLabel || (en ? 'Source article' : '图文来源')}<ArrowUpRight size={16}/></a>}</DialogContent></Dialog>;
}
