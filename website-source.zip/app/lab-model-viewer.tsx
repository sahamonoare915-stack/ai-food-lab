'use client';

import { createElement, useEffect, useRef, useState } from 'react';
import { Expand, RotateCcw, LoaderCircle } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

type Translate = (zh: string, en: string) => string;
type ModelElement = HTMLElement & {
  cameraOrbit: string;
  cameraTarget: string;
  fieldOfView: string;
  jumpCameraToGoal: () => void;
  updateFraming: () => Promise<void>;
};
let viewerModule: Promise<unknown> | undefined;
const initialOrbit = '-38deg 50deg auto';

function InteractiveModel({ t, expanded = false }: { t: Translate; expanded?: boolean }) {
  const holder = useRef<HTMLDivElement>(null);
  const viewer = useRef<ModelElement>(null);
  const [active, setActive] = useState(expanded);
  const [ready, setReady] = useState(false);
  const [status, setStatus] = useState<'loading' | 'loaded' | 'error'>('loading');
  const [attempt, setAttempt] = useState(0);

  useEffect(() => {
    if (active) return;
    if (!('IntersectionObserver' in window)) { setActive(true); return; }
    const observer = new IntersectionObserver(entries => {
      if (entries.some(entry => entry.isIntersecting)) { setActive(true); observer.disconnect(); }
    }, { rootMargin: '250px' });
    if (holder.current) observer.observe(holder.current);
    return () => observer.disconnect();
  }, [active]);

  useEffect(() => {
    if (!active) return;
    let cancelled = false;
    const url = new URL('./vendor/model-viewer.min.js', document.baseURI).href;
    viewerModule ??= import(/* @vite-ignore */ url).then(module => {
      module.ModelViewerElement.dracoDecoderLocation = new URL('./vendor/draco/', document.baseURI).href;
      return module;
    }).catch(error => { viewerModule = undefined; throw error; });
    viewerModule.then(() => { if (!cancelled) setReady(true); }).catch(() => { if (!cancelled) setStatus('error'); });
    return () => { cancelled = true; };
  }, [active, attempt]);

  useEffect(() => {
    const element = viewer.current;
    if (!ready || !element) return;
    const loaded = () => setStatus('loaded');
    const failed = () => setStatus('error');
    element.addEventListener('load', loaded);
    element.addEventListener('error', failed);
    return () => {
      element.removeEventListener('load', loaded);
      element.removeEventListener('error', failed);
    };
  }, [ready, attempt]);

  function resetView() {
    const element = viewer.current;
    if (!element) return;
    element.cameraOrbit = initialOrbit;
    element.cameraTarget = 'auto auto auto';
    element.fieldOfView = '30deg';
    element.jumpCameraToGoal();
  }

  return <div className={`lab-model-frame${expanded ? ' lab-model-expanded' : ''}`} ref={holder}>
    {ready && createElement('model-viewer', {
      key: attempt,
      ref: viewer,
      src: './models/food-lab.glb',
      alt: t('可旋转、缩放的实验室三维空间布局模型', 'An interactive 3D laboratory layout that you can rotate and zoom'),
      'camera-controls': true,
      'touch-action': 'pan-y',
      'camera-orbit': initialOrbit,
      'camera-target': 'auto auto auto',
      'field-of-view': '30deg',
      'min-camera-orbit': 'auto 5deg 30%',
      'max-camera-orbit': 'auto 85deg 220%',
      'shadow-intensity': '0.7',
      'shadow-softness': '0.8',
      exposure: '1',
      'interaction-prompt': 'none',
      loading: 'eager',
      tabindex: 0,
    })}
    {status !== 'loaded' && <div className="lab-model-cover">
      <img src="./images/food-lab-3d-preview.jpg" alt={t('实验室三维布局预览', 'Preview of the 3D laboratory layout')} width={1200} height={900}/>
      <div className="lab-model-status" role="status">
        {status === 'error' ? <><span>{t('3D 模型暂未加载成功', 'The 3D model could not be loaded')}</span><button type="button" onClick={() => { setStatus('loading'); setReady(false); setAttempt(n => n + 1); }}>{t('重新加载', 'Try again')}</button></> : <><LoaderCircle size={18} className={active ? 'lab-model-spinner' : undefined}/><span>{t(active ? '正在加载 3D 模型…' : '实验室 3D 布局', active ? 'Loading 3D model…' : '3D laboratory layout')}</span></>}
      </div>
    </div>}
    <button type="button" className="lab-model-reset" onClick={resetView} disabled={status !== 'loaded'} aria-label={t('恢复模型初始视角', 'Reset the model view')}><RotateCcw size={16}/>{t('复位视角', 'Reset view')}</button>
  </div>;
}

export function LabModelViewer({ t }: { t: Translate }) {
  const [expanded, setExpanded] = useState(false);
  return <div className="lab-model-panel">
    <InteractiveModel t={t}/>
    <div className="lab-model-toolbar"><p>{t('拖动旋转 · 滚轮或双指缩放', 'Drag to rotate · Scroll or pinch to zoom')}</p>
      <Dialog open={expanded} onOpenChange={setExpanded}>
        <DialogTrigger className="lab-model-expand"><Expand size={16}/>{t('放大查看', 'Enlarge view')}</DialogTrigger>
        <DialogContent className="lab-model-modal sm:max-w-6xl">
          <DialogTitle>{t('实验室空间 · 3D 布局', 'Laboratory space · 3D layout')}</DialogTitle>
          <DialogDescription>{t('拖动旋转模型，使用滚轮或双指缩放；方向键也可旋转视角。', 'Drag to rotate, scroll or pinch to zoom. Arrow keys also rotate the view.')}</DialogDescription>
          {expanded && <InteractiveModel t={t} expanded/>}
        </DialogContent>
      </Dialog>
    </div>
  </div>;
}
