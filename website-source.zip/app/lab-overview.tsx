import { ArrowRight, BrainCircuit, Database, FlaskConical, Fingerprint, ShieldCheck, Network, Layers, Bot } from 'lucide-react';

type Translate = (zh: string, en: string) => string;

const principles = [
  ['准确性', 'Accuracy', '以真实样本与复杂混合菜品检验识别和营养估算，关注误差与适用范围。', 'Evaluate recognition and nutrient estimates against real samples and mixed dishes, reporting errors and scope.'],
  ['可解释性', 'Explainability', '通过特征归因、通路分析与反事实推理，将预测转化为可验证的保鲜与包装策略。', 'Use feature attribution, pathway analysis and counterfactual reasoning to develop testable preservation and packaging strategies.'],
  ['物理一致性', 'Physical consistency', '将传热、传质和反应动力学融入模型，研究加工过程预测与数字孪生。', 'Incorporate heat transfer, mass transfer and reaction kinetics into process prediction and digital twins.'],
  ['诚实性', 'Honesty', '披露不确定性，以证据支撑结论，保留可追溯记录并开展专家复核。', 'Disclose uncertainty, support conclusions with evidence, retain traceable records and involve expert review.'],
];

export function ResearchOverview({ t }: { t: Translate }) {
  return <section className="research-overview wrap" aria-labelledby="frontiers-heading">
    <div className="section-head"><div><p className="eyebrow">RESEARCH PROGRAMMES</p><h2 id="frontiers-heading">{t('研究平台与前沿构想', 'Research platforms & future directions')}</h2></div></div>
    <div className="programme-grid">
      <article className="programme-card"><BrainCircuit className="programme-icon" aria-hidden="true"/><span className="programme-status">{t('研究框架', 'RESEARCH FRAMEWORK')}</span><h3>{t('食品数字大脑', 'Food intelligence framework')}</h3><p>{t('围绕产品创新、配方设计、工艺优化与个性化营养，探索多智能体协同。食品知识图谱连接原料、成分、结构和功能，支持科学推理与实验验证。', 'Explore collaborating agents for product innovation, formulation, process optimization and personalized nutrition. Food knowledge graphs connect ingredients, composition, structure and function with scientific reasoning and experimental validation.')}</p><div className="programme-caption">{t('任务理解 · 知识推理 · 实验反馈', 'Task understanding · Knowledge reasoning · Experimental feedback')}</div></article>
      <article className="programme-card"><Fingerprint className="programme-icon" aria-hidden="true"/><span className="programme-status">{t('研究构想', 'RESEARCH CONCEPT')}</span><h3>FoodPersona</h3><p>{t('面向食品产品研发，探索基于消费者画像的虚拟感官评价。结合配方、工艺、风味与质构进行候选方案筛选，再通过真实消费者评价校准与验证。', 'Explore virtual sensory evaluation based on consumer profiles. Screen candidate formulations, processes, flavors and textures, then calibrate and validate the results through real consumer evaluation.')}</p><div className="programme-caption">{t('虚拟筛选辅助研发，真实评价验证结果', 'Virtual screening supports R&D; real evaluation validates results')}</div></article>
      <article className="programme-card"><FlaskConical className="programme-icon" aria-hidden="true"/><span className="programme-status">{t('研究案例', 'RESEARCH CASE')}</span><h3>{t('AI 设计食品包装', 'AI for food packaging')}</h3><p>{t('结合自动化制备、多性能表征与主动学习，研究可降解食品包装的配方与性能。围绕透明度、力学性能和保鲜需求，形成模型推荐与实验反馈的迭代过程。', 'Combine automated preparation, characterization of multiple properties and active learning to study biodegradable food packaging. Iterate between model recommendations and experiments for optical, mechanical and preservation requirements.')}</p><div className="programme-caption">{t('配方推荐 · 自动制备 · 性能验证', 'Formulation · Automated preparation · Validation')}</div></article>
    </div>
    <div className="principles-head"><ShieldCheck size={25} aria-hidden="true"/><h3>{t('可信食品 AI 的四项研究原则', 'Four principles for trustworthy food AI')}</h3></div>
    <div className="principles-grid">{principles.map(([zh, en, text, textEn], i) => <article key={en}><span className="principle-number">0{i + 1}</span><h4>{t(zh, en)}</h4><p>{t(text, textEn)}</p></article>)}</div>
    <p className="source-note">{t('研究框架与构想依据实验室学术报告整理；FoodPersona 的虚拟评价不能替代真实感官证据。', 'Frameworks and concepts are summarized from the laboratory presentation. Virtual FoodPersona evaluations do not replace evidence from real sensory studies.')}</p>
  </section>;
}

const layers = [
  { Icon: FlaskConical, title: '场景应用层', en: 'Applications', text: '自动化取样制样、液体处理与高通量筛选、营养与功能因子检测、感知质控，以及智慧垂直农场。', textEn: 'Automated sampling and preparation, liquid handling and high-throughput screening, nutrient and functional-factor analysis, quality sensing and vertical farming.' },
  { Icon: Database, title: '资源管理层', en: 'Resources & orchestration', text: '通过 FoodClaw 与 Lab / AI Agents 组织样品和实验数据、检测结果、模型算法、知识图谱、仪器接口、任务调度及实验日志。', textEn: 'FoodClaw and Lab / AI Agents organize sample and experiment data, analytical results, models, knowledge graphs, instrument interfaces, task scheduling and logs.' },
  { Icon: Layers, title: '硬件层', en: 'Hardware', text: '连接机器人工作站、液体处理与分析检测设备、光谱成像、种植系统及边缘计算，为实验流程提供支撑。', textEn: 'Connect robotic workstations, liquid-handling and analytical instruments, spectral imaging, cultivation systems and edge computing.' },
];
const workflow = [
  ['自主控制', 'Autonomous control', '建立核心实验单元的稳定执行能力。', 'Establish reliable execution within individual experimental units.'],
  ['流程闭环', 'Closed workflows', '联动设备，将实验结果反馈到后续任务。', 'Coordinate instruments and feed results into subsequent tasks.'],
  ['前处理与转移', 'Preparation & transfer', '连接样品前处理、移动执行和跨区域调度。', 'Connect sample preparation, mobile execution and transfer between areas.'],
  ['异地孪生', 'Remote digital twins', '探索实验映射、远程操作与跨空间协同。', 'Explore experimental mapping, remote operation and collaboration across locations.'],
];
const levels = [
  ['L1', '单机自动化', 'Instrument automation'], ['L2', '仪器联网', 'Connected instruments'], ['L3', '模型辅助闭环', 'Model-assisted closed loops'], ['L4', '跨实验室协同', 'Cross-laboratory coordination'], ['L5', '自主设计与发现', 'Autonomous design & discovery'],
];

export function LabPlatform({ t }: { t: Translate }) {
  return <div className="lab-platform">
    <div className="section-head"><div><p className="eyebrow">FOODCLAW · LAB AGENTS</p><h2>{t('数据、模型与实验的协同平台', 'Connecting data, models & experiments')}</h2></div></div>
    <div className="platform-layout"><div className="platform-layers">{layers.map(({ Icon, title, en, text, textEn }, i) => <article className="platform-layer" key={en}><div className="layer-label"><Icon size={22} aria-hidden="true"/><span>0{i + 1}</span></div><div><h3>{t(title, en)}</h3><p>{t(text, textEn)}</p></div></article>)}</div><div className="platform-workflow"><div className="workflow-heading"><Network size={24} aria-hidden="true"/><h3>{t('实验室能力发展主线', 'Laboratory development pathway')}</h3></div><ol>{workflow.map(([zh, en, text, textEn], i) => <li key={en}><span>{String(i + 1).padStart(2, '0')}</span><div><h4>{t(zh, en)}</h4><p>{t(text, textEn)}</p></div></li>)}</ol></div></div>
    <div className="equipment-strip"><span>{t('报告介绍的设备方向', 'Equipment areas in the presentation')}</span><p>LC–MS/MS · UPLC · {t('高分辨质谱 · 近红外与高光谱成像 · 自动移液 · 机器人与 AGV · 垂直农场 · 边缘计算', 'High-resolution MS · Near-infrared & hyperspectral imaging · Automated pipetting · Robotics & AGVs · Vertical farming · Edge computing')}</p></div>
    <div className="levels-heading"><Bot size={24} aria-hidden="true"/><h3>{t('智能食品实验室五级发展框架', 'Five levels of smart food laboratories')}</h3><span>{t('报告提出的框架', 'PROPOSED FRAMEWORK')}</span></div>
    <ol className="lab-levels">{levels.map(([level, zh, en], i) => <li key={level}><strong>{level}</strong><span>{t(zh, en)}</span>{i < levels.length - 1 && <ArrowRight size={17} aria-hidden="true"/>}</li>)}</ol>
    <p className="source-note">{t('平台组成与发展主线依据实验室报告展示。五级框架用于描述能力演进，不代表实验室已经达到全部级别；长期方向包括多智能体闭环、持续学习与具身食品智能。', 'Platform components and development pathways follow the laboratory presentation. The five levels describe a progression, not a claim that every level has been reached. Longer-term directions include collaborating agents, continual learning and embodied food intelligence.')}</p>
  </div>;
}

export function TeamCulture({ t }: { t: Translate }) {
  return <div className="team-culture"><div><p className="eyebrow">OUR APPROACH</p><h3>{t('平等协作，共同成长', 'Equal partnership, shared growth')}</h3></div><p>{t('以平等尊重、公开透明和共同目标开展合作，让 AI 工具承担重复工作、促进知识流动。支持成员主动探索、跨学科协作，将更多精力投入科学问题与创造性研究。', 'We value mutual respect, transparency and shared goals. AI tools support routine work and knowledge exchange, giving researchers more space for initiative, interdisciplinary collaboration and creative scientific inquiry.')}</p></div>;
}
