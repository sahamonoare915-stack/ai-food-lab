import { FigurePreview } from './figure-preview';

type Translate = (zh: string, en: string) => string;
const projects = [
  {
    id: 'explainable-gnn',
    title: '膳食多样性与抗衰老', en: 'Dietary diversity and aging',
    method: 'GNN · 可解释性智能', methodEn: 'GNN · Explainable intelligence',
    image: './images/projects/dietary-diversity-aging.jpg',
    question: '膳食多样性的抗衰老机制解析',
    questionEn: 'Elucidating the anti-aging mechanisms of dietary diversity',
    innovations: [
      ['钳形仿生图神经网络算法', 'Pincer-inspired biomimetic graph neural network algorithm'],
      ['网络药理消融解释性分析', 'Ablation-based interpretability analysis in network pharmacology'],
    ],
  },
  {
    id: 'generative-gan',
    title: '电鳗仿生材料', en: 'Electric-eel-inspired materials',
    method: 'ISAF · 生物界面信号', methodEn: 'ISAF · Biointerface signaling',
    image: './images/projects/electric-eel-biointerface.png',
    question: '电鳗仿生材料调控生物界面信号传递',
    questionEn: 'Regulating biointerface signal transmission with electric-eel-inspired materials',
    innovations: [
      ['感知功能一体化算法ISAF', 'ISAF algorithm integrating sensing and function'],
      ['生物基电鳗仿生材料制备', 'Fabrication of biobased electric-eel-inspired materials'],
    ],
  },
  {
    id: 'brain-inspired-snn',
    title: '光–香气多组学', en: 'Light–aroma multi-omics',
    method: 'SNN · 光控风味', methodEn: 'SNN · Light-controlled flavor',
    image: './images/projects/light-aroma-multiomics.jpg',
    question: '光-香气多组学通路解析',
    questionEn: 'Decoding light–aroma pathways through multi-omics',
    innovations: [
      ['从农场到质谱黑灯实验室', 'A farm-to-mass-spectrometry lights-out laboratory'],
      ['脉冲神经网络解析指纹质谱', 'Spiking neural networks for mass-spectral fingerprint interpretation'],
    ],
  },
  {
    id: 'embodied-pinn',
    title: '美拉德反应复杂机制解析', en: 'Decoding complex Maillard reaction mechanisms',
    method: '多智能体 · 原位质谱', methodEn: 'Multi-agent AI · In situ mass spectrometry',
    image: './images/projects/maillard-reaction-mechanisms.jpg',
    question: '美拉德反应复杂机制解析',
    questionEn: 'Elucidating the complex mechanisms of the Maillard reaction',
    innovations: [
      ['食品美拉德反应多模态数据库', 'A multimodal database of Maillard reactions in food'],
      ['多智能体原位质谱成分解析算法', 'Multi-agent algorithms for component identification using in situ mass spectrometry'],
    ],
  },
];

export function PosterProjects({ t, en }: { t: Translate; en: boolean }) {
  return <section className="poster-projects wrap" aria-labelledby="poster-projects-heading">
    <div className="section-head"><div>
      <p className="eyebrow">{t('正在进行的科学研究项目', 'ONGOING RESEARCH PROJECTS')}</p>
      <h2 id="poster-projects-heading">{t('AI重新发现食品科学', 'AI rediscovers food science')}</h2>
    </div></div>
    <div className="poster-project-grid">{projects.map((p, i) =>
      <article className="poster-project" id={p.id} key={p.id}>
        <div className="poster-visual">
          <FigurePreview src={p.image} title={t(p.title, p.en)}
            caption={t('研究概念图，用于展示正在开展的研究方向。', 'Concept illustration of an ongoing research direction.')}
            sourceHref={p.image} sourceLabel={t('打开完整图片', 'Open full image')} en={en}/>
          <span className="poster-number">0{i + 1}</span>
        </div>
        <div className="poster-project-copy">
          <p className="project-method">{t(p.method, p.methodEn)}</p>
          <h3>{t(p.title, p.en)}</h3>
          <dl>
            <div><dt>{t('科学问题', 'SCIENTIFIC QUESTION')}</dt><dd>{t(p.question, p.questionEn)}</dd></div>
            <div><dt>{t('关键技术创新', 'KEY TECHNOLOGICAL INNOVATIONS')}</dt>
              <dd><ul className="project-innovations">{p.innovations.map(([zh, english]) => <li key={zh}>{t(zh, english)}</li>)}</ul></dd>
            </div>
          </dl>
        </div>
      </article>
    )}</div>
  </section>;
}
