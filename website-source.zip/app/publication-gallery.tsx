'use client';

import { useState } from 'react';
import { ArrowUpRight, ChevronDown, FileText, Sparkles } from 'lucide-react';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { FigurePreview } from './figure-preview';
import publicationData from './publications.json';

type Translate = (zh: string, en: string) => string;
type Publication = {
 id: string; doi: string; title: string; titleZh: string; source: string; year: number; journal: string; authors: string[]; forthcomingIssue: boolean;
 figureSrc?: string; figureCaptionZh?: string; figureCaptionEn?: string; figureSource?: string; figureKindZh?: string; figureKindEn?: string; highlightZh?: string; highlightEn?: string;
};
const papers: Publication[] = publicationData;
const scholar='https://scholar.google.com/citations?user=pndu_IQAAAAJ&hl=zh-CN&oi=ao';
const external={target:'_blank',rel:'noopener noreferrer'};
const manuscripts=[
 {title:'The AI Palate: Uniting the Global Flavor Community Through Interactive Data Platforms',titleZh:'AI 味觉：以交互式数据平台连接全球风味研究共同体',authors:'Peihua Ma, Imre Blank, Ping Yang, Ziyang Wu, Jinyuan Sun',image:'./images/papers/manuscript-palate.jpeg',caption:'图 1 · AI Palate 交互式风味科学概念框架，来自作者提供文稿。',captionEn:'Figure 1: conceptual framework for interactive flavor science, from the supplied manuscript.',highlight:'以交互式平台连接风味分子、感官证据与智能体，支持可验证的风味研究。',highlightEn:'Connects flavor molecules, sensory evidence and agents in an interactive platform for testable flavor research.'},
 {title:'AI can cheat scientists, but never itself',titleZh:'AI 可以欺骗科学家，却无法欺骗自身',authors:'Peihua Ma, Dachuan Zhang, Yizhou Ma, Zhenjiao Du, Xiaoxue Jia, Jixu Tong, Bei Fan, Fengzhong Wang',image:'./images/papers/manuscript-honesty.png',caption:'图 1 · 将诚实性纳入 AI 科研质量控制，来自作者提供文稿。',captionEn:'Figure 1: honesty as a quality-control criterion for AI-enabled science, from the supplied manuscript.',highlight:'将“诚实性”纳入科研 AI 评估，检验压力下的证据、结论与不确定性是否保持一致。',highlightEn:'Adds operational honesty to research-AI evaluation by testing whether claims, evidence and uncertainty remain stable under pressure.'},
];

function PaperFigure({ p, t, en, className='' }: { p: Publication; t: Translate; en: boolean; className?: string }) {
 return p.figureSrc ? <div className={`paper-figure-block ${className}`}><FigurePreview src={p.figureSrc} title={t(p.titleZh,p.title)} caption={t(p.figureCaptionZh||'',p.figureCaptionEn||'')} sourceHref={p.figureSource||p.source} sourceLabel={t('原文及图片来源','Article and figure source')} en={en}/><span className="paper-figure-kind">{t(p.figureKindZh||'研究图',p.figureKindEn||'RESEARCH FIGURE')}</span></div> : null;
}

function PaperCard({ p, i, t, en }: { p: Publication; i: number; t: Translate; en: boolean }) {
 return <article className="publication-card" id={p.id}><PaperFigure p={p} t={t} en={en}/><div className="publication-copy"><p className="paper-journal"><span className="publication-index">{String(i+1).padStart(2,'0')}</span>{p.journal}<span>{p.forthcomingIssue?t('在线论文 · 卷期 2026.11','Online · issue 2026.11'):p.year}</span></p><h3><a href={p.source} {...external}>{t(p.titleZh,p.title)}</a></h3>{!en&&<p className="original-title" lang="en">{p.title}</p>}{p.highlightZh&&<p className="paper-highlight"><Sparkles size={16} aria-hidden="true"/><span>{t(p.highlightZh,p.highlightEn||'')}</span></p>}<div className="publication-meta"><details className="authors"><summary>{p.authors.slice(0,3).join(', ')}{p.authors.length>3?' et al.':''}<span>{t('作者','Authors')}<ChevronDown size={13}/></span></summary><p>{p.authors.map((name,j)=><span key={j}>{j>0?', ':''}{name==='Peihua Ma'?<strong>{name}</strong>:name}</span>)}</p></details><a className="paper-doi" href={p.source} {...external}>{t('阅读原文','Read article')}<ArrowUpRight size={16}/></a></div></div></article>;
}

export function PublicationGallery({t,en}:{t:Translate;en:boolean}) {
 const [allPapers,setAllPapers]=useState(false);
 const recent=papers.filter(p=>p.year===2026), selected=papers.filter(p=>p.year===2025);
 const featured=papers.find(p=>p.id==='paper-4')!;
 return <section className="publications-section" id="publications"><div className="wrap"><div className="section-head"><div><p className="eyebrow">RESEARCH OUTPUT</p><h2>{t('成果展示','Publications')}</h2></div><a className="text-link" href={scholar} {...external}>Google Scholar<ArrowUpRight size={17}/></a></div>
 <article className="featured-publication"><PaperFigure p={featured} t={t} en={en}/><div className="featured-publication-copy"><p className="paper-kicker">iMeta · 2026 · e70139</p><h3><a href={featured.source} {...external}>{t(featured.titleZh,featured.title)}</a></h3>{!en&&<p className="original-title" lang="en">{featured.title}</p>}<p className="paper-highlight"><Sparkles size={17} aria-hidden="true"/><span>{t(featured.highlightZh||'',featured.highlightEn||'')}</span></p><div className="paper-actions"><a href={featured.source} {...external}>{t('阅读论文','Read article')}<ArrowUpRight size={16}/></a><a href="./papers/imt2-70139.pdf" {...external}><FileText size={16}/>{t('全文 PDF','Full text PDF')}</a></div></div></article>
 <h3 className="recent-papers-heading">{t('近期代表性论文','Recent representative publications')}</h3><Tabs defaultValue="2026" className="paper-tabs"><TabsList variant="line" className="year-tabs"><TabsTrigger value="2026">2026<span>{recent.length}</span></TabsTrigger><TabsTrigger value="2025">{t('2025 选录','2025 selected')}<span>{selected.length}</span></TabsTrigger><TabsTrigger value="manuscripts">{t('研究文稿','Manuscripts')}<span>{manuscripts.length}</span></TabsTrigger></TabsList>{[['2026',recent],['2025',selected]].map(([year,items])=><TabsContent key={String(year)} value={String(year)}><div className="publication-list">{(items as Publication[]).slice(0,year==='2026'&&!allPapers?5:99).map((p,i)=><PaperCard key={p.id} p={p} i={i} t={t} en={en}/>)}</div>{year==='2026'&&<button className="show-papers" onClick={()=>setAllPapers(!allPapers)} aria-expanded={allPapers}>{allPapers?t('收起论文列表','Show fewer papers'):t(`查看全部 ${recent.length} 篇近期论文`,`View all ${recent.length} recent papers`)}<ChevronDown className={allPapers?'rotated':''} size={17}/></button>}</TabsContent>)}<TabsContent value="manuscripts"><div className="manuscript-note">{t('以下图文根据作者提供的文稿整理，正式发表信息尚待确认。','These illustrated entries are based on supplied manuscripts; formal publication details remain to be confirmed.')}</div>{manuscripts.map(m=><article className="publication-card manuscript-card" key={m.title}><div className="paper-figure-block"><FigurePreview src={m.image} title={t(m.titleZh,m.title)} caption={t(m.caption,m.captionEn)} en={en}/><span className="paper-figure-kind">{t('文稿研究图','MANUSCRIPT FIGURE')}</span></div><div className="publication-copy"><span className="status-badge">{t('文稿','MANUSCRIPT')}</span><h3>{t(m.titleZh,m.title)}</h3>{!en&&<p className="original-title" lang="en">{m.title}</p>}<p className="paper-highlight"><Sparkles size={16} aria-hidden="true"/><span>{t(m.highlight,m.highlightEn)}</span></p><p className="manuscript-authors">{m.authors}</p></div></article>)}</TabsContent></Tabs>
 <p className="source-note">{t('中文题名为译文，英文原题保留供核对。亮点依据可获取的论文摘要、正文或作者文稿提炼，配图来源见大图说明。论文清单核对日期：2026.09.08，完整成果仍待与导师主页核对。','Chinese titles are translations; original titles are retained for reference. Highlights summarize available abstracts, full text or supplied manuscripts. Figure sources appear in the enlarged view. Records checked on 8 September 2026; reconciliation with the full Scholar list remains pending.')}</p></div></section>;
}
