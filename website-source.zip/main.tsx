import { createRoot, hydrateRoot } from 'react-dom/client';
import Home from './app/page';
import './app/globals.css';
import './app/research-media.css';

const root = document.getElementById('root')!;
if (root.hasChildNodes() && root.querySelector('main')) {
  hydrateRoot(root, <Home />);
} else {
  createRoot(root).render(<Home />);
}
