import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { readFile, writeFile, cp, mkdir } from 'node:fs/promises';

const root = fileURLToPath(new URL('..', import.meta.url));
const require = createRequire(import.meta.url);
const vite = join(dirname(require.resolve('vite/package.json')), 'bin/vite.js');

for (const prerender of ['0', '1']) {
  const result = spawnSync(process.execPath, [vite, 'build'], {
    cwd: root,
    env: { ...process.env, LAB_PRERENDER: prerender },
    stdio: 'inherit',
  });
  if (result.status !== 0) process.exit(result.status || 1);
}

const { render } = await import('../.prerender/prerender.mjs');
const html = render();
if (!html.includes('AI') || !html.includes('id="publications"')) {
  throw new Error('The laboratory homepage did not render.');
}
const indexPath = join(root, 'dist/index.html');
const template = await readFile(indexPath, 'utf8');
if (!template.includes('<!--app-html-->')) throw new Error('Missing prerender placeholder.');
await writeFile(indexPath, template.replace('<!--app-html-->', () => html));
await mkdir(join(root, 'docs'), { recursive: true });
await cp(join(root, 'dist'), join(root, 'docs'), { recursive: true });
console.log('Static website ready in docs/ (GitHub Pages) and dist/ (preview).');
