import bpy, json, time
from pathlib import Path
from mathutils import Vector

site=Path(__file__).resolve().parents[1]
root=site/'public/models'
(site/'public/models').mkdir(exist_ok=True)
scene=bpy.context.scene
assert not bpy.context.preferences.filepaths.use_scripts_auto_execute
selected=[obj for obj in scene.objects if obj.type in {'MESH','CURVE','FONT','SURFACE','META'} and obj.visible_get() and not obj.hide_render]
print('Exporting visible scene geometry: '+str(len(selected))+' objects',flush=True)
bpy.ops.object.select_all(action='DESELECT')
for obj in selected: obj.select_set(True)
bpy.context.view_layer.objects.active=next(obj for obj in selected if obj.type=='MESH')
bpy.ops.object.convert(target='MESH')
meshes=[obj for obj in bpy.context.selected_objects if obj.type=='MESH']
bpy.context.view_layer.objects.active=meshes[0]
bpy.ops.object.join()
model=bpy.context.object
model.name='Food Lab — complete laboratory layout'
print('Joined mesh: '+str(len(model.data.vertices))+' vertices, '+str(len(model.data.polygons))+' polygons',flush=True)
model_path=site/'public/models/food-lab.glb'
bpy.ops.export_scene.gltf(filepath=str(model_path),export_format='GLB',use_selection=True,use_active_scene=True,use_visible=True,use_renderable=True,export_apply=True,export_animations=False,export_cameras=False,export_lights=False,export_extras=False,export_materials='EXPORT',export_image_format='AUTO',export_yup=True,export_draco_mesh_compression_enable=True,export_draco_mesh_compression_level=6,export_draco_position_quantization=16)
print('Web model exported: '+str(model_path.stat().st_size)+' bytes',flush=True)
positions=[model.matrix_world@Vector(corner) for corner in model.bound_box]
report={'source_file':'food_lab_rechecked (1).blend','blender':bpy.app.version_string,'scene':scene.name,'source_geometry_objects':len(selected),'vertices':len(model.data.vertices),'polygons':len(model.data.polygons),'materials':len(model.data.materials),'glb_bytes':model_path.stat().st_size,'bounds':{'min':[min(p[i] for p in positions) for i in range(3)],'max':[max(p[i] for p in positions) for i in range(3)]}}
(root/'food-lab-source.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')

# Render a faithful loading preview from the supplied scene camera.
scene.render.engine='CYCLES'
scene.cycles.device='CPU'
scene.cycles.samples=16
scene.cycles.use_denoising=True
scene.render.resolution_x=1200
scene.render.resolution_y=900
scene.render.resolution_percentage=100
scene.render.image_settings.file_format='JPEG'
scene.render.image_settings.quality=88
scene.render.filepath=str(site/'public/images/food-lab-3d-preview.jpg')
scene.render.film_transparent=False
print('Rendering preview from '+scene.camera.name,flush=True)
bpy.ops.render.render(write_still=True)
print('Preview render finished.',flush=True)
