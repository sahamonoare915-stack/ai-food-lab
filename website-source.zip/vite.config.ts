import { fileURLToPath, URL } from 'node:url';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/postcss';
import { defineConfig } from 'vite';

const prerender = process.env.LAB_PRERENDER === '1';

export default defineConfig({
  base: './',
  plugins: [react()],
  resolve: {
    alias: { '@': fileURLToPath(new URL('.', import.meta.url)) },
    dedupe: ['react', 'react-dom'],
  },
  css: { postcss: { plugins: [tailwindcss()] } },
  build: prerender
    ? {
        ssr: 'scripts/prerender.tsx',
        outDir: '.prerender',
        copyPublicDir: false,
        rollupOptions: { output: { entryFileNames: 'prerender.mjs' } },
      }
    : { outDir: 'dist' },
});
